// A node for a Binary Search Tree (BST)
#ifndef _NODE
#define _NODE

struct node
{
	int data;
	node *left;
	node *right;
};

#endif

