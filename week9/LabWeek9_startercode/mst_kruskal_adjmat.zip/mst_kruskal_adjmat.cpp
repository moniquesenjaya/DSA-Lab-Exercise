// Simple C++ implementation for Kruskal's algorithm
// using Adjacency Matrix
#include <bits/stdc++.h>
using namespace std;

#define INF INT_MAX
#define V 5
int parent[V];
  
// Find set of vertex i
int find(int i)
{
    while (parent[i] != i)
        i = parent[i];
    return i;
}
  
// Does union of i and j. It returns
// false if i and j are already in same
// set.
void union1(int i, int j)
{
    int a = find(i);
    int b = find(j);
    parent[a] = b;
}
  
// Finds MST using Kruskal's algorithm
void kruskalMST(int cost[][V])
{
    int mincost = 0; // Cost of min MST.
  
    // Initialize sets of disjoint sets.
    for (int i = 0; i < V; i++)
        parent[i] = i;
  
    // Include minimum weight edges one by one
    cout<<"Edge \tWeight\n"; 

    int edge_count = 0;
    while (edge_count < V - 1) {
        int min = INF, a = -1, b = -1;
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (find(i) != find(j) && cost[i][j] < min) {
                    min = cost[i][j];
                    a = i;
                    b = j;
                }
            }
        }
  
        union1(a, b);

		edge_count++;
        cout << a << " - " << b << "\t" << min << " \n";
        //cout << "Edge " << edge_count++ << " : (" << a << ", " << b << ") weight : " << min << " \n";
        mincost += min;
    }
    cout << "\n Minimum cost (weight) = " << mincost << "\n";
}
  
// driver program to test above function
int main()
{
	// SAMPLE GRAPH 1
	// Notice that you replace 0 with INF (INFINITE) in the original adj matrix
    int cost[][V] = {
        { INF,   2, INF,   6, INF },
        {   2, INF,   3,   8,   5 },
        { INF,   3, INF, INF,   7 },
        {   6,   8, INF, INF,   9 },
        { INF,   5,   7,   9, INF },
    };


	// SAMPLE GRAPH 2: Please create adjacency matrix here, 0 replaced with INF
	// make sure you change the #define V 9


	// SAMPLE GRAPH 3 Please create adjacency matrix here, 0 replaced with INF
	// make sure you change the #define V 10

	
    // Print the solution
    cout << "MST using Kruskal algorithm\n";
    cout << "---------------------------\n"; 
    cout << "Please, make sure your set the size of the matrix correctly at the #define V\n\n";
    kruskalMST(cost);
  
    return 0;
}

